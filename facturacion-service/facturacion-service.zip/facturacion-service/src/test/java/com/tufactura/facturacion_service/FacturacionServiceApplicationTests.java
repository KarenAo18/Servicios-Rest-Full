package com.tufactura.facturacion_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturacionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
